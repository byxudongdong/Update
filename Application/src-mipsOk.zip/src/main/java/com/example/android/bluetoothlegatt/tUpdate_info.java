package com.example.android.bluetoothlegatt;

/**
 * Created by byxdd on 2016/6/28 0028.
 */
public class tUpdate_info {
    public  byte[][] ppVer_Str =new byte[20][];
    public  byte[] hw_info =new byte[4];
    public  byte[] image_size=new byte[4] ;
    public  byte[] image_crc =new byte[4];
    public  byte[]  image_data = new byte[126*1024];
}
