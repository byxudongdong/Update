package com.bluetooth;

public interface bluetoothListen {
	public void mOnBluetoothListen(BluetoothLeService mBluetoothLeService);
}
